var structAELineSegment2 =
[
    [ "mN", "structAELineSegment2.html#a440a780a1c5a8aba181bfcaf4caede32", null ],
    [ "mNdotP0", "structAELineSegment2.html#ac947ab5417f0baa0af4479231a931bbe", null ],
    [ "mP0", "structAELineSegment2.html#ad443206608e8b211c2c8a333e63af72e", null ],
    [ "mP1", "structAELineSegment2.html#a470db7bfd1e41f78115fd0161d832448", null ]
];