var structAEGfxTexture =
[
    [ "mpName", "structAEGfxTexture.html#abf4a81e2f473b1bc3e1fb0f322fee5ad", null ],
    [ "mpSurface", "structAEGfxTexture.html#a02e661883026336df4c081cab80a43d1", null ]
];